#import <Foundation/Foundation.h>

#ifndef C7D_DDA_h
#define C7D_DDA_h

@interface DDA : NSObject

+ (void)d;
+ (IMP)vector;

@end

#endif
