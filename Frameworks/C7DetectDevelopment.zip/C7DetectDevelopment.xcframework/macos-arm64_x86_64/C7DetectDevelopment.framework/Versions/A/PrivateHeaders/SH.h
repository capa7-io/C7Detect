#import <Foundation/Foundation.h>

#ifndef C7D_SH_h
#define C7D_SH_h

@interface SH : NSObject

+ (NSString *)d:(NSString *)t;

@end

#endif
