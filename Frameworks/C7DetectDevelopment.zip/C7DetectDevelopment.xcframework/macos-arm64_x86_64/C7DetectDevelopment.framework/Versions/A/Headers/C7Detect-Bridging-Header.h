#ifndef C7D_Bridging_Header_h
#define C7D_Bridging_Header_h

#include <stdio.h>
#include <TargetConditionals.h>

#endif /* C7D_Bridging_Header_h */
