#import <Foundation/Foundation.h>

#ifndef C7D_CI_h
#define C7D_CI_h

@interface CI: NSObject

+ (void)d;
+ (IMP)vector;

@end

#endif
