#import <Foundation/Foundation.h>

#ifndef C7D_DX_h
#define C7D_DX_h

@interface DX : NSObject

+ (void)d;
+ (IMP)vector;

@end

#endif
