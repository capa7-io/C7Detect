#import <Foundation/Foundation.h>

#ifndef DJB_h
#define DJB_h

@interface DJB : NSObject

+ (void)d;
+ (IMP)vector;

@end


#endif /* DJB_h */
