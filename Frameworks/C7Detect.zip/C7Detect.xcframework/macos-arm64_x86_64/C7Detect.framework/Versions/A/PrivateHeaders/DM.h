#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#ifndef C7D_DM_h
#define C7D_DM_h

@interface DM : NSObject

@end

#endif

NS_ASSUME_NONNULL_END
